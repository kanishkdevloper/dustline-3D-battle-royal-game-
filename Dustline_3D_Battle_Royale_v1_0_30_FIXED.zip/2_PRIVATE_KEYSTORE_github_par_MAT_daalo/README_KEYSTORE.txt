KEYSTORE (upload key) - PRIVATE. Isko GitHub par KABHI upload mat karna.

KYA HUA
- Aapki bheji hui file "dustline-upload.jks.txt" ko upload ke dauran text maan kar badal diya gaya:
  1030 bytes "�" (replacement character) ban gaye. Asli file ~2559 bytes ki honi chahiye thi, ye 4619 bytes ki hai.
- keytool / openssl / Gradle isko keystore nahi maante ("Unrecognized keystore format"). Gaye hue bytes wapas nahi aa sakte.
- Isliye ye file (dustline-upload.jks.txt.DAMAGED_original) sirf record ke liye rakhi hai, isse APK/AAB sign NAHI hoga.
- File ke andar alias "dustline" aur banne ka time 11 Nov 2026 dikhta hai.

ASLI FILE KAISE DEIN (koi ek tareeka)
1) Apne PC par asli dustline-upload.jks ko ZIP kar ke chat mein bhejo (zip binary theek rehta hai), ya
2) PC par ye chalao aur sirf output text bhejo / GitHub Secret mein daalo:
     Windows PowerShell : [Convert]::ToBase64String([IO.File]::ReadAllBytes("dustline-upload.jks"))
     Mac / Linux        : base64 -w0 dustline-upload.jks
   Ye text hi GitHub Secret KEYSTORE_BASE64 ki value hai (text ki tarah safe rehta hai).
3) Agar asli file / password kho gaya aur is key se abhi tak Play Console par KOI upload nahi hua, to nayi key bana lo:
   GitHub > Actions > "Make upload key (one time)" ya tools/make-keystore.sh.
   (Agar is key se pehle upload ho chuka hai to Play Console > App signing > "Request upload key reset" chahiye.)

SIGNING KAISE CHALEGA (key sahi file milne ke baad)
- GitHub Actions: 4 secrets: KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS (= dustline), KEY_PASSWORD.
- Apne PC par: dustline-upload.jks ko 1_PROJECT_github_par_daalo ke root mein rakho, keystore.properties.example ko
  keystore.properties naam se copy karke apna password bharo.
Password mujhe nahi pata aur main andaza nahi lagata - woh sirf aapke paas hai.
